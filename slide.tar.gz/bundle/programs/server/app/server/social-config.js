(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/social-config.js                                             //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
ServiceConfiguration.configurations.remove({                           // 1
    service: 'facebook'                                                // 2
});                                                                    //
                                                                       //
ServiceConfiguration.configurations.insert({                           // 5
    service: 'facebook',                                               // 6
    appId: '827655450665383',                                          // 7
    secret: '0a4b7a1249b4a1b5cbbdaa9fa5542398'                         // 8
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=social-config.js.map
