(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods.js                                                   //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.methods({                                                       // 1
	// methodName: function() {                                           //
	// 	// method body                                                    //
	// },                                                                 //
	addHighScore: function (opts) {                                       // 5
		var sortBy = opts.sort || -1;                                        // 6
		var compare = opts.sort === 1 ? function (s, h) {                    // 7
			return s < h;                                                       // 8
		} : function (s, h) {                                                //
			return s > h;                                                       // 10
		};                                                                   //
		var board = Array(Array(null, null, null, null), Array(null, null, null, null), Array(null, null, null, null), Array(null, null, null, null));
		var highs = HighScores.find({ userId: this.userId, game: opts.game }, { sort: { score: sortBy } }).fetch();
                                                                       //
		for (var i = 0; i < 4; i++) {                                        // 15
			for (var j = 0; j < 4; j++) {                                       // 16
				if (opts.board[i][j]) {                                            // 17
					board[j][i] = opts.board[i][j].v;                                 // 18
				}                                                                  //
			}                                                                   //
		}                                                                    //
                                                                       //
		if (highs.length < 5) {                                              // 23
			HighScores.insert({                                                 // 24
				userId: this.userId,                                               // 25
				game: opts.game,                                                   // 26
				score: opts.score,                                                 // 27
				board: board                                                       // 28
			});                                                                 //
		} else if (highs[4] && highs[4]._id && highs[4].score) {             //
			if (compare(opts.score, highs[4].score)) {                          // 31
				HighScores.update(highs[4]._id, { $set: {                          // 32
						score: opts.score,                                               // 33
						board: board                                                     // 34
					} });                                                             //
			}                                                                   //
		}                                                                    //
	}                                                                     //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=methods.js.map
