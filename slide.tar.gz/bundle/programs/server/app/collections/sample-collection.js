(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// collections/sample-collection.js                                    //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// ContactsLists = new Meteor.Collection('contacts-lists');            //
                                                                       //
// Users = new Meteor.Collection('users');                             //
// localUser = new Ground.Collection(Users);                           //
                                                                       //
HighScores = new Meteor.Collection('high-scores');                     // 6
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=sample-collection.js.map
