(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// shared/router.js                                                    //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Router.configure({                                                     // 1
	layoutTemplate: 'layout',                                             // 2
	onBeforeAction: function () {                                         // 3
		this.next();                                                         // 4
	}                                                                     //
});                                                                    //
                                                                       //
Router.route('/', {                                                    // 8
	template: 'appBody'                                                   // 9
});                                                                    //
                                                                       //
Router.route('/(.*)', {                                                // 12
	template: 'appBody'                                                   // 13
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=router.js.map
